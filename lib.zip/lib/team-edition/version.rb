module Team
  module Edition
    VERSION = "0.0.1"
  end
end
